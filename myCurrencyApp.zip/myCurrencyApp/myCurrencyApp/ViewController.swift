//
//  ViewController.swift
//  myCurrencyApp
//
//  Created by Anastasia Athans-Stothoff on 6/7/20.
//  Copyright © 2020 Anastasia Athans-Stothoff. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.tintColor = UIColor.white
        navigationController?.navigationBar.barTintColor = UIColor.purple
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        performSegue(withIdentifier: "Pass1", sender: self)
   
        func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
    performSegue(withIdentifier: "Pass2", sender: self)
    
    
    
    }
        func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let nextVC = segue.destination as! SecondViewController
        nextVC.navigationItem.title = "This is a Thai baht"
        nextVC.receivingString = "I love currency!"
    
    let customButton = UIBarButtonItem()
        customButton.title = "Go Back"
        navigationItem.backBarButtonItem = customButton
        
    }
    
    
    
    
    
}

}
