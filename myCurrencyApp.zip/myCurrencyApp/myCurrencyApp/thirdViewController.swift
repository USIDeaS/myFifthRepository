//
//  thirdViewController.swift
//  myCurrencyApp
//
//  Created by Anastasia Athans-Stothoff on 6/8/20.
//  Copyright © 2020 Anastasia Athans-Stothoff. All rights reserved.
//

import UIKit

class thirdViewController: UIViewController {
//BILL: I TRIED ATTACHING THE THIRD LABEL TO AN OUTLET HERE, BUT THE OUTLET BOX WOULD NOT APPEAR.
    override func viewDidLoad() {
        super.viewDidLoad()

        _ = ""
        
       // labelShowMe.text = receivingString
        
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
